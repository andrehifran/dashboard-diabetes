# exemplo de código Python
